from database import SessionLocal, Product

products = [
    {"name": "Wireless Headphones", "category": "Electronics", "description": "Noise-canceling wireless headphones with long battery life.", "price": 150},
    {"name": "Smartwatch", "category": "Wearable Tech", "description": "Waterproof smartwatch with heart rate monitoring and GPS.", "price": 200},
    {"name": "Yoga Mat", "category": "Fitness", "description": "Eco-friendly non-slip yoga mat for all fitness levels.", "price": 50},
]

db = SessionLocal()

for p in products:
    product = Product(name=p["name"], category=p["category"], description=p["description"], price=p["price"])
    db.add(product)

db.commit()
db.close()
