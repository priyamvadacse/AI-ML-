from fastapi import FastAPI, Depends
from sqlalchemy.orm import Session
from database import get_db, Product
import openai
import redis
import json

app = FastAPI()

# Redis cache setup
redis_client = redis.Redis(host="localhost", port=6379, db=0, decode_responses=True)

# OpenAI API Key (Replace with your actual key)
openai.api_key = "YOUR_OPENAI_API_KEY"

@app.get("/")
def home():
    return {"message": "Welcome to the Product Recommendation API"}

@app.post("/recommendations/")
def get_recommendations(user_id: str, browsing_history: list[str], db: Session = Depends(get_db)):
    # Check Redis cache first
    cached_result = redis_client.get(user_id)
    if cached_result:
        return json.loads(cached_result)

    # Find matching products based on category
    products = db.query(Product).filter(Product.category.in_(browsing_history)).all()

    # Format for LLM input
    product_texts = [f"{p.name}: {p.description}" for p in products]
    prompt = f"Based on user browsing history {browsing_history}, recommend products from the following:\n" + "\n".join(product_texts)

    # Get LLM recommendations
    response = openai.ChatCompletion.create(
        model="gpt-3.5-turbo",
        messages=[{"role": "user", "content": prompt}]
    )
    recommended_texts = response["choices"][0]["message"]["content"]

    # Convert LLM output to structured JSON
    recommendations = [{"id": p.id, "name": p.name, "category": p.category, "description": p.description, "price": p.price} for p in products]

    # Store in Redis cache
    redis_client.setex(user_id, 3600, json.dumps({"user_id": user_id, "recommendations": recommendations}))

    return {"user_id": user_id, "recommendations": recommendations}
